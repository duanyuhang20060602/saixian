from pathlib import Path
import sys,json,hashlib,shutil,zipfile
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'5.0project/tools'))
from build_v4_port import inputs
out=root/'delivery-formatter-trim-20261030'
out.mkdir(exist_ok=True)
records={}
for board in 'ab':
    folder=sys.argv[1] if board=='b' and len(sys.argv)>1 else 'build-formatter-trim-20261030'
    path=root/f'{folder}/builds/board_{board}/result.json'
    record=json.loads(path.read_text())
    assert record['status']=='passed' and record['toolchain_unchanged']
    assert record['inputs_sha256']==inputs('board_'+board)
    assert record['timing_ns']['SWNS']>=0 and record['timing_ns']['HWNS']>=0
    for kind in ['bit','area','timing']:
        file=Path(record[kind]['path'])
        assert hashlib.sha256(file.read_bytes()).hexdigest()==record[kind]['sha256']
        shutil.copy2(file,out/file.name)
    shutil.copy2(path,out/f'board_{board}_build.json')
    records[board]=record
for name in ['bytes','equivalence']:
    file=root/'validation-formatter-trim-20261030'/(name+'.log')
    text=file.read_text();assert 'PASS ' in text and 'FATAL' not in text
    shutil.copy2(file,out/file.name)
prior={'a':json.loads((root/'build-hmi-trim-a19-20261030/builds/board_a/result.json').read_text()),'b':json.loads((root/'build-compact-b19/builds/board_b/result.json').read_text())}
lines=['# 2026-10-30 HMI formatter width trim','',
 'Only HMI formatter counter/length widths change: refresh_count 32 -> 25 at 100MHz, prefix_length 6 -> 5, suffix_length 6 -> 3. Total message length remains 6 bits to represent 32 bytes. All clocks, baud rates and protocol lengths remain unchanged. The rotating-trophy commit fix is retained.','',
 'The source file is shared by both projects; both boards were rebuilt with identical current input hashes. A board does not instantiate the modified formatter module.','',
 '| Board | LUT previous -> new | Registers previous -> new | RAM9K / RAM32K / DSP | setup / hold ns |','|---|---|---|---|---|']
for board in 'ab':
    r=records[board];v=r['resources'];p=prior[board]['resources'];t=r['timing_ns']
    lines.append(f"| {board.upper()} | {p['lut']} -> {v['lut']} | {p['reg']} -> {v['reg']} | {v['bram']} / {v['bram32k']} / {v['dsp']} | {t['SWNS']} / {t['HWNS']} |")
lines+=['','Checks pass: five-page HMI byte comparison against reference; 100MHz cycle equivalence with 1064 bytes and 40 commands, refresh-count rollover, maximum-length numeric settings, page switches and randomized backpressure. Both routed timing checks pass. Physical hardware validation is pending.','', 'This is a width-only change; it does not improve link speed or shorten packets. Some synthesis width trimming may already occur automatically; resource changes above are measured from routed reports.']
(out/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
with zipfile.ZipFile(out/'source_and_tests.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in ['5.0project/common/photo_processing.v','5.0project/tests/tb_formatter_width_equivalence.v','5.0project/tests/tb_hmi_byte_stream.v','validation-formatter-trim-20261030/formatter_reference.v','build_formatter_trim_20261030.py','package_formatter_trim_20261030.py']:
        z.write(root/name,name)
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps({b:{'resources':r['resources'],'timing_ns':r['timing_ns']} for b,r in records.items()},indent=2))
