from pathlib import Path
import sys,os,json
sys.path.insert(0,str(Path('5.0project/tools').resolve()))
from build_v4_port import build
board=sys.argv[1]
folder='build-hmi-trim-a19-20261030' if board=='a' else 'build-compact-b19'
record=json.loads(Path(f'{folder}/builds/board_{board}/result.json').read_text())
os.environ['SAIXIAN_TEMP_ROOT']=str(Path('temp-formatter-trim-'+board).resolve())
os.environ['SAIXIAN_PLACE_SEED']=record['place_seed_override']
os.environ['SAIXIAN_PHYSICAL_STRATEGY']=record['physical_strategy']['name']
if record.get('synthesis_strategy'):os.environ['SAIXIAN_SYNTHESIS_STRATEGY']=record['synthesis_strategy']['name']
build(board,Path('build-formatter-trim-20261030').resolve())
