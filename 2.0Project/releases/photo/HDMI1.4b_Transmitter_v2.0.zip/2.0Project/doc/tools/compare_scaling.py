"""Software scaling comparison; no FPGA synthesis/board validation implied.

Nearest and bilinear use production Q16 endpoint positions, Q8 weights and
RGB565 intermediate/final storage. Cubic is a quantized software reference.
"""
from pathlib import Path
import argparse
import numpy as np
from PIL import Image,ImageDraw

def rgb565(a):
    a=np.clip(a,0,255).astype(np.int32)
    r=a[...,0]>>3;g=a[...,1]>>2;b=a[...,2]>>3
    return np.stack([(r<<3)|(r>>2),(g<<2)|(g>>4),(b<<3)|(b>>2)],axis=-1)

def positions(n,m):
    if m==1:return np.zeros(1,dtype=np.int64)
    p=np.arange(m,dtype=np.int64)*(((n-1)<<16)//(m-1))
    p[-1]=(n-1)<<16
    return p

def resize(a,w,h,mode):
    a=np.asarray(a,dtype=np.int32)
    py=positions(a.shape[0],h);px=positions(a.shape[1],w)
    xf=px>>16;yf=py>>16;fx=px&65535;fy=py&65535
    xc=np.minimum(xf+(fx!=0),a.shape[1]-1);yc=np.minimum(yf+(fy!=0),a.shape[0]-1)
    if mode=='nearest':
        out=rgb565(a[(yf+(fy>=32768))[:,None],(xf+(fx>=32768))[None,:]])
    elif mode=='bilinear':
        horizontal=rgb565(a[:,xf]+((a[:,xc]-a[:,xf])*(fx>>8)[None,:,None]>>8))
        out=rgb565(horizontal[yf]+((horizontal[yc]-horizontal[yf])*(fy>>8)[:,None,None]>>8))
    elif mode=='cubic':
        def weights(f):
            t=f/65536.0
            return [-.5*t+t*t-.5*t*t*t,1-2.5*t*t+1.5*t*t*t,
                    .5*t+2*t*t-1.5*t*t*t,-.5*t*t+.5*t*t*t]
        horizontal=np.zeros((a.shape[0],w,3),dtype=np.float64)
        for offset,c in zip([-1,0,1,2],weights(fx)):
            horizontal+=a[:,np.clip(xf+offset,0,a.shape[1]-1)]*c[None,:,None]
        horizontal=rgb565(np.floor(horizontal+.5))
        out=np.zeros((h,w,3),dtype=np.float64)
        for offset,c in zip([-1,0,1,2],weights(fy)):
            out+=horizontal[np.clip(yf+offset,0,a.shape[0]-1)]*c[:,None,None]
        out=rgb565(np.floor(out+.5))
    else:raise ValueError(mode)
    return out.astype(np.uint8)

def checks():
    for mode in ['nearest','bilinear','cubic']:
        for value in [0,17,128,255]:
            a=np.full((3,4,3),value,dtype=np.uint8);out=resize(a,7,5,mode)
            assert np.all(out==rgb565(a)[0,0])
        a=np.arange(36,dtype=np.uint8).reshape(3,4,3)*7
        out=resize(a,7,5,mode)
        assert np.array_equal(out[0,0],rgb565(a)[0,0])
        assert np.array_equal(out[-1,-1],rgb565(a)[-1,-1])
    # Independent nearest-coordinate enumeration, including exact endpoints.
    a=np.arange(36,dtype=np.uint8).reshape(3,4,3)*7;out=resize(a,7,5,'nearest')
    for y in range(5):
        for x in range(7):
            qx=(3<<16) if x==6 else x*((3<<16)//6)
            qy=(2<<16) if y==4 else y*((2<<16)//4)
            ix=(qx>>16)+((qx&65535)>=32768);iy=(qy>>16)+((qy&65535)>=32768)
            assert np.array_equal(out[y,x],rgb565(a)[iy,ix])
    print('PASS software constant fields, forced endpoints, RGB565 and independent nearest enumeration')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    checks();root=Path(__file__).resolve().parents[2]
    a=np.asarray(Image.open(root/'doc/TF卡上卡素材_20260925/05-1.bmp').convert('RGB'))
    args.output.mkdir(parents=True,exist_ok=True)
    sheet=Image.new('RGB',(1200,610),'#202020');draw=ImageDraw.Draw(sheet)
    for i,mode in enumerate(['nearest','bilinear','cubic']):
        out=resize(a,1280,720,mode);im=Image.fromarray(out)
        im.save(args.output/(mode+'.png'))
        sheet.paste(im.resize((384,216),Image.Resampling.NEAREST),(i*400+8,35))
        # Identical crop and identical display magnification for all methods.
        crop=im.crop((540,275,730,435)).resize((380,320),Image.Resampling.NEAREST)
        sheet.paste(crop,(i*400+8,280))
        draw.text((i*400+8,10),mode+' / RGB565 / software only',fill='white')
    sheet.save(args.output/'comparison.png')
    print('Generated actual 640x480 photo -> 1280x720 software references:',args.output)
    print('Cubic has not been implemented or budgeted in FPGA RTL. No existing bitstream changed.')

if __name__=='__main__':main()
